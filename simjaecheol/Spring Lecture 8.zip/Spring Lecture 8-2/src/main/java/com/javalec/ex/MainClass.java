package com.javalec.ex;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext ctx = new GenericXmlApplicationContext("classpath:applicationCTX.xml");
		
		
		AdminConnection adminconnection = ctx.getBean("adminConnection",AdminConnection.class);
		System.out.println(adminconnection.getAdminid());
		System.out.println(adminconnection.getAdminpw());
		System.out.println(adminconnection.getSub_adminid());
		System.out.println(adminconnection.getSub_adminpw());
		
		
	}

}
