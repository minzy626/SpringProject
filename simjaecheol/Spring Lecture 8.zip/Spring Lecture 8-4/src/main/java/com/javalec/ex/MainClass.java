package com.javalec.ex;

import java.util.Scanner;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

public class MainClass {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String config;
		
		Scanner scanner = new Scanner(System.in);
		config = scanner.next();
		if("dev".equals(config))
			config="dev";
		else if("run".equals(config))
			config="run";
		
		GenericXmlApplicationContext ctx = new GenericXmlApplicationContext();
		ctx.getEnvironment().setActiveProfiles(config);
		ctx.load("applicationCTX_dev.xml","applicationCTX_run.xml");
		ctx.refresh();
		
		ServerInfo info = ctx.getBean("serverInfo",ServerInfo.class);
		System.out.println(info.getIp());
		System.out.println(info.getPort());
	}

}
