package com.javalec.ex;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

@Configuration
public class ApplicationConfig {
	@Value("${admin.id}")
	private String adminid;
	@Value("${admin.pw}")
	private String adminpw;
	@Value("${sub_admin.id}")
	private String sub_adminid;
	@Value("${sub_admin.pw}")
	private String sub_adminpw;
	
	@Bean
	public static PropertySourcesPlaceholderConfigurer Properties()
	{
		PropertySourcesPlaceholderConfigurer configurer = new PropertySourcesPlaceholderConfigurer();
		Resource[] resources = new Resource[2];
		resources[0] = new ClassPathResource("admin.properties");
		resources[1] = new ClassPathResource("sub_admin.properties");
		configurer.setLocations(resources);
		
		return configurer;
	}
	
	@Bean
	public AdminConnection adminConfig()
	{
		AdminConnection adminConnection = new AdminConnection();
		adminConnection.setAdminid(adminid);
		adminConnection.setAdminpw(adminpw);
		adminConnection.setSub_adminid(sub_adminid);
		adminConnection.setSub_adminpw(sub_adminpw);
		return adminConnection;
	}
	
	
	
	
}
